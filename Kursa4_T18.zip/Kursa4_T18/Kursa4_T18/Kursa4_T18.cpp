﻿#include <iostream>
#include <fstream>
#include <string>
#include "Ru.h"

using namespace std;

struct Voter {
    string name;
    string address;
    int age;
    int pollingStation;
    int yearOfVoting;
    string vote; // "да", "нет", "воздержусь"
    Voter* next;
};

struct VoterList {
    Voter* head;

    VoterList() : head(nullptr) {}

    void displayMenu() {
        cout << "----------------------------------------------------------------------" << endl;
        cout << "Введите в консоль номер для реализации программой какого-либо действия" << endl;
        cout << "----------------------------------------------------------------------" << endl;
        cout << "1. Вывести всех избирателей" << endl;
        cout << "2. Добавить избирателя в начало списка" << endl;
        cout << "3. Добавить избирателя в конец списка" << endl;
        cout << "4. Добавить избирателя после определенного избирателя" << endl;
        cout << "5. Добавить избирателя перед определенным избирателем" << endl;
        cout << "6. Удалить избирателя из списка" << endl;
        cout << "7. Вывести сведения о положительных голосах по возрастным группам" << endl;
        cout << "8. Вывести сведения о негативных голосах и воздержавшихся" << endl;
        cout << "9. Создать список для определенного участка" << endl;
        cout << "10. Сохранить данные списка в бинарный файл" << endl;
        cout << "11. Вывести (извлечь) данные из бинарного файла" << endl;
        cout << "12. Выход" << endl;
        cout << "----------------------------------------------------------------------" << endl;
        cout << endl;
    }

    // Вывести всех избирателей
    void displayAllVoters() {
        Voter* current = head;
        while (current != nullptr) {
            cout << "ФИО: " << current->name << endl;
            cout << "Адрес: " << current->address << endl;
            cout << "Возраст: " << current->age << endl;
            cout << "Номер участка: " << current->pollingStation << endl;
            cout << "Год голосования: " << current->yearOfVoting << endl;
            cout << "Голос: " << current->vote << endl;
            cout << endl;
            current = current->next;
        }
    }

    // Добавить избирателя в начало списка
    void addVoterAtBeginning(const Voter& newVoter) {
        Voter* newNode = new Voter(newVoter);
        newNode->next = head;
        head = newNode;
    }

    // Добавить избирателя в конец списка
    void addVoterAtEnd(const Voter& newVoter) {
        Voter* newNode = new Voter(newVoter);
        if (head == nullptr) {
            head = newNode;
        }
        else {
            Voter* current = head;
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = newNode;
        }
    }

    // Добавить избирателя после определенного избирателя
    void addVoterAfter(const string& targetName, const Voter& newVoter) {
        Voter* newNode = new Voter(newVoter);
        Voter* current = head;
        while (current != nullptr && current->name != targetName) {
            current = current->next;
        }
        if (current != nullptr) {
            newNode->next = current->next;
            current->next = newNode;
        }
        else {
            cout << "Избиратель с именем " << targetName << " не найден." << endl;
        }
    }

    // Добавить избирателя перед определенным избирателем
    void addVoterBefore(const string& targetName, const Voter& newVoter) {
        Voter* newNode = new Voter(newVoter);
        if (head != nullptr && head->name == targetName) {
            newNode->next = head;
            head = newNode;
        }
        else {
            Voter* current = head;
            while (current->next != nullptr && current->next->name != targetName) {
                current = current->next;
            }
            if (current->next != nullptr) {
                newNode->next = current->next;
                current->next = newNode;
            }
            else {
                cout << "Избиратель с именем " << targetName << " не найден." << endl;
            }
        }
    }

    // Удалить избирателя из списка
    void removeVoter(const string& targetName) {
        if (head == nullptr) {
            cout << "Список избирателей пуст." << endl;
            return;
        }
        if (head->name == targetName) {
            Voter* temp = head;
            head = head->next;
            delete temp;
            cout << "Избиратель с именем " << targetName << " удален из списка." << endl;
            return;
        }
        Voter* current = head;
        while (current->next != nullptr && current->next->name != targetName) {
            current = current->next;
        }
        if (current->next != nullptr) {
            Voter* temp = current->next;
            current->next = current->next->next;
            delete temp;
            cout << "Избиратель с именем " << targetName << " удален из списка." << endl;
        }
        else {
            cout << "Избиратель с именем " << targetName << " не найден." << endl;
        }
    }

    // Вывести сведения о положительных голосах по возрастным группам
    void displayPositiveVotesByAgeGroups() {
        int countUnder30 = 0, count30to50 = 0, countOver50 = 0;
        Voter* current = head;
        while (current != nullptr) {
            if (current->vote == "yes") {
                if (current->age < 30) {
                    countUnder30++;
                }
                else if (current->age >= 30 && current->age <= 50) {
                    count30to50++;
                }
                else {
                    countOver50++;
                }
            }
            current = current->next;
        }
        cout << "Положительные голоса:" << endl;
        cout << "Младше 30 лет: " << countUnder30 << endl;
        cout << "От 30 до 50 лет: " << count30to50 << endl;
        cout << "Старше 50 лет: " << countOver50 << endl;
    }

    // Вывести сведения о негативных голосах и воздержавшихся
    void displayNegativeAndAbstainVotes() {
        Voter* current = head;
        cout << "Негативные голоса и воздержавшиеся:" << endl;
        while (current != nullptr) {
            if (current->vote == "no" || current->vote == "abstain") {
                cout << "ФИО: " << current->name << endl;
                cout << "Адрес: " << current->address << endl;
                cout << "Возраст: " << current->age << endl;
                cout << "Номер участка: " << current->pollingStation << endl;
                cout << "Год голосования: " << current->yearOfVoting << endl;
                cout << "Голос: " << current->vote << endl;
                cout << endl;
            }
            current = current->next;
        }
    }

    // Создать список для определенного участка
    VoterList createListForPollingStation(int stationNumber) {
        VoterList newList;
        Voter* current = head;
        while (current != nullptr) {
            if (current->pollingStation == stationNumber) {
                Voter newVoter = { current->name, current->address, current->age, current->pollingStation, current->yearOfVoting, current->vote, nullptr };
                newList.addVoterAtEnd(newVoter);
            }
            current = current->next;
        }
        return newList;
    }

    // Сохранить данные в бинарного файла
    void saveToBinaryFile(const string& filename) {
        ofstream outFile(filename, ios::binary);
        if (!outFile.is_open()) {
            cout << "Ошибка при открытии файла." << endl;
            return;
        }
        Voter* current = head;
        while (current != nullptr) {
            // Запись размера строки и самой строки
            int nameSize = current->name.size();
            outFile.write(reinterpret_cast<char*>(&nameSize), sizeof(int));
            outFile.write(current->name.c_str(), nameSize);

            int addressSize = current->address.size();
            outFile.write(reinterpret_cast<char*>(&addressSize), sizeof(int));
            outFile.write(current->address.c_str(), addressSize);

            // Запись остальных данных
            outFile.write(reinterpret_cast<char*>(&current->age), sizeof(current->age));
            outFile.write(reinterpret_cast<char*>(&current->pollingStation), sizeof(current->pollingStation));
            outFile.write(reinterpret_cast<char*>(&current->yearOfVoting), sizeof(current->yearOfVoting));

            // Запись голоса
            int voteSize = current->vote.size();
            outFile.write(reinterpret_cast<char*>(&voteSize), sizeof(int));
            outFile.write(current->vote.c_str(), voteSize);

            current = current->next;
        }
        outFile.close();
        cout << "Данные сохранены в бинарный файл." << endl;
    }

    // Извлечь данные из бинарного файла
    void readFromBinaryFile(const string& filename) {
        ifstream inFile(filename, ios::binary);
        if (!inFile.is_open()) {
            cout << "Ошибка при открытии файла." << endl;
            return;
        }

        while (true) {
            Voter newVoter;
            // Чтение строк
            int nameSize;
            inFile.read(reinterpret_cast<char*>(&nameSize), sizeof(int));
            if (inFile.fail()) break;
            newVoter.name.resize(nameSize);
            inFile.read(&newVoter.name[0], nameSize);

            int addressSize;
            inFile.read(reinterpret_cast<char*>(&addressSize), sizeof(int));
            if (inFile.fail()) break;
            newVoter.address.resize(addressSize);
            inFile.read(&newVoter.address[0], addressSize);

            // Чтение остальных данных
            inFile.read(reinterpret_cast<char*>(&newVoter.age), sizeof(newVoter.age));
            inFile.read(reinterpret_cast<char*>(&newVoter.pollingStation), sizeof(newVoter.pollingStation));
            inFile.read(reinterpret_cast<char*>(&newVoter.yearOfVoting), sizeof(newVoter.yearOfVoting));

            // Чтение голоса
            int voteSize;
            inFile.read(reinterpret_cast<char*>(&voteSize), sizeof(int));
            if (inFile.fail()) break;
            newVoter.vote.resize(voteSize);
            inFile.read(&newVoter.vote[0], voteSize);

            // Вывод данных из файла
            cout << "ФИО: " << newVoter.name << endl;
            cout << "Адрес: " << newVoter.address << endl;
            cout << "Возраст: " << newVoter.age << endl;
            cout << "Номер участка: " << newVoter.pollingStation << endl;
            cout << "Год голосования: " << newVoter.yearOfVoting << endl;
            cout << "Голос: " << newVoter.vote << endl;
            cout << endl;
        }

        inFile.close();
        cout << "Данные загружены из бинарного файла." << endl;
    }


    ~VoterList() {
        while (head != nullptr) {
            Voter* temp = head;
            head = head->next;
            delete temp;
        }
    }
};


int main(int argc, char* argv[]) {
    ConsoleCP cp(1251);
    VoterList voters;

    Voter voter1 = { "Иванов Иван Иванович", "ул. Пушкина, д. 10", 35, 1, 2024, "да", nullptr };
    Voter voter2 = { "Петров Петр Петрович", "ул. Лермонтова, д. 5", 45, 2, 2024, "нет", nullptr };
    Voter voter3 = { "Сидоров Сидор Сидорович", "ул. Гоголя, д. 20", 25, 1, 2024, "воздержусь", nullptr };
    Voter voter4 = { "Козлов Алексей Владимирович", "ул. Толстого, д. 15", 28, 3, 2024, "да", nullptr };
    Voter voter5 = { "Смирнова Ольга Петровна", "ул. Чехова, д. 8", 50, 2, 2024, "нет", nullptr };
    Voter voter6 = { "Николаева Мария Ивановна", "ул. Достоевского, д. 25", 40, 4, 2024, "да", nullptr };

    voters.addVoterAtEnd(voter1);
    voters.addVoterAtEnd(voter2);
    voters.addVoterAtEnd(voter3);
    voters.addVoterAtEnd(voter4);
    voters.addVoterAtEnd(voter5);
    voters.addVoterAtEnd(voter6);

    while (true) {
        voters.displayMenu();
        int choice;
        if (!(cin >> choice)) {
            cout << "Ошибка: введите числовое значение." << endl;
            cin.clear(); // Очистка флагов ошибки ввода
            cin.ignore(1000, '\n');
            continue;
        }

        switch (choice) {
        case 1: // Вывести всех избирателей
            voters.displayAllVoters();
            break;
        case 2: // Добавить избирателя в начало списка
        {
            string name, address, vote;
            int age, pollingStation, yearOfVoting;
            cout << "Введите ФИО: ";
            cin.ignore();
            getline(cin, name);
            cout << "Введите адрес: ";
            getline(cin, address);
            cout << "Введите возраст: ";
            cin >> age;
            cout << "Введите номер участка: ";
            cin >> pollingStation;
            cout << "Введите год голосования: ";
            cin >> yearOfVoting;
            cout << "Введите голос (да / нет / воздержусь): ";
            cin >> vote;
            Voter newVoter = { name, address, age, pollingStation, yearOfVoting, vote, nullptr };
            voters.addVoterAtBeginning(newVoter);
            break;
        }
        case 3: // Добавить избирателя в конец списка
        {
            string name, address, vote;
            int age, pollingStation, yearOfVoting;
            cout << "Введите ФИО: ";
            cin.ignore();
            getline(cin, name);
            cout << "Введите адрес: ";
            getline(cin, address);
            cout << "Введите возраст: ";
            cin >> age;
            cout << "Введите номер участка: ";
            cin >> pollingStation;
            cout << "Введите год голосования: ";
            cin >> yearOfVoting;
            cout << "Введите голос (да / нет / воздержусь): ";
            cin >> vote;
            Voter newVoter = { name, address, age, pollingStation, yearOfVoting, vote, nullptr };
            voters.addVoterAtEnd(newVoter);
            break;
        }
        case 4: // Добавить избирателя после определенного избирателя
        {
            string targetName, name, address, vote;
            int age, pollingStation, yearOfVoting;
            cout << "Введите имя после которого нужно добавить избирателя: ";
            cin.ignore();
            getline(cin, targetName);
            cout << "Введите ФИО: ";
            getline(cin, name);
            cout << "Введите адрес: ";
            getline(cin, address);
            cout << "Введите возраст: ";
            cin >> age;
            cout << "Введите номер участка: ";
            cin >> pollingStation;
            cout << "Введите год голосования: ";
            cin >> yearOfVoting;
            cout << "Введите голос (да / нет / воздержусь): ";
            cin >> vote;
            Voter newVoter = { name, address, age, pollingStation, yearOfVoting, vote, nullptr };
            voters.addVoterAfter(targetName, newVoter);
            break;
        }
        case 5: // Добавить избирателя перед определенным избирателем
        {
            string targetName, name, address, vote;
            int age, pollingStation, yearOfVoting;
            cout << "Введите имя перед которым нужно добавить избирателя: ";
            cin.ignore();
            getline(cin, targetName);
            cout << "Введите ФИО: ";
            getline(cin, name);
            cout << "Введите адрес: ";
            getline(cin, address);
            cout << "Введите возраст: ";
            cin >> age;
            cout << "Введите номер участка: ";
            cin >> pollingStation;
            cout << "Введите год голосования: ";
            cin >> yearOfVoting;
            cout << "Введите голос (да / нет / воздержусь): ";
            cin >> vote;
            Voter newVoter = { name, address, age, pollingStation, yearOfVoting, vote, nullptr };
            voters.addVoterBefore(targetName, newVoter);
            break;
        }
        case 6: // Удалить избирателя из списка
        {
            string targetName;
            cout << "Введите имя избирателя для удаления: ";
            cin.ignore();
            getline(cin, targetName);
            voters.removeVoter(targetName);
            break;
        }
        case 7: // Вывести сведения о положительных голосах по возрастным группам
            voters.displayPositiveVotesByAgeGroups();
            break;
        case 8: // Вывести сведения о негативных голосах и воздержавшихся
            voters.displayNegativeAndAbstainVotes();
            break;
        case 9: // Создать список для определенного участка
        {
            int stationNumber;
            cout << "Введите номер участка для создания списка: ";
            cin >> stationNumber;
            VoterList newList = voters.createListForPollingStation(stationNumber);
            cout << "Список для участка " << stationNumber << ":" << endl;
            newList.displayAllVoters();
            break;
        }
        case 10: // Сохранить данные списка в бинарный файл
        {
            string filename;
            cout << "Введите имя файла для сохранения данных: ";
            cin.ignore();
            getline(cin, filename);
            voters.saveToBinaryFile(filename);
            break;
        }
        case 11: // Извлечь данные из бинарного файла
        {
            string filename;
            cout << "Введите имя файла для загрузки данных: ";
            cin.ignore();
            getline(cin, filename);
            voters.readFromBinaryFile(filename);
            break;
        }
        case 12: // Выход
            cout << "Программа завершена." << endl;
            return 0;
        default:
            cout << "Некорректный ввод. Пожалуйста, выберите действие из списка." << endl;
        }
    }
}